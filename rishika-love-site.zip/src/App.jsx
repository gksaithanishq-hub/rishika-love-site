import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Howl } from "howler";

// Backgrounds from your uploads
const backgrounds = [
  "/images/3a240bcd-0483-4ac4-aa4e-9773e4753f40.png",
  "/images/1ad2c920-4c21-4ca5-8e70-f3d1b149ba57.png",
  "/images/3582c59a-8d75-4bc4-a83b-2dd5477fd12d.png",
  "/images/729f117a-a2ea-484f-b323-2ef33d7fa319.png",
  "/images/9ccacb52-e272-4713-9762-ee86b62a520f.png",
  "/images/fa9348a7-a766-458e-b040-0169e964769c.png",
  "/images/1f4be607-bf73-480f-b229-98be5ea16dc4.png",
];

const messages = [
  "You're the kind of girl the moon writes poetry about, Rishika.",
  "When you smile, even stars slow down to stare, Rishika.",
  "Your laugh? That’s the sweetest song I’ve ever heard, Rishika.",
  "You’re not just pretty, baby — you’re unreal. Like silk dreams, Rishika.",
  "Every move you make feels like art on display, Rishika.",
  "You make love feel easy, soft, and unforgettable, Rishika.",
  "Rishika, I want your name carved in every heartbeat I’ve got.\n— Yours, Thanishq 💗"
];

let audio;

if (typeof window !== "undefined") {
  audio = new Howl({
    src: ["/audio/be990cc7-e1cf-40f1-89c2-d39f85d93a63.mp3"],
    volume: 0.7,
    onplay: () => setTimeout(() => audio.fade(0.7, 0, 3000), 27000),
  });
}

export default function App() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (audio) audio.play();

    const handleKeyDown = (e) => {
      if (e.code === "Space") {
        setIndex((prev) => (prev + 1) % backgrounds.length);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0 bg-cover bg-center blur-[2px]"
          style={{ backgroundImage: `url(${backgrounds[index]})` }}
        />
      </AnimatePresence>

      <div className="absolute inset-0 flex items-center justify-center p-4">
        <motion.div
          key={`msg-${index}`}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -30 }}
          transition={{ duration: 1 }}
          className="text-white text-3xl md:text-5xl font-serif text-center max-w-3xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]"
        >
          {messages[index]}
        </motion.div>
      </div>
    </div>
  );
}
